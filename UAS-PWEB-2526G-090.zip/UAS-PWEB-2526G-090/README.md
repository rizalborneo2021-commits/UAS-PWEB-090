# UAS Pemrograman Web - Sistem Informasi Inventaris Barang

Dokumentasi ini dibuat untuk memenuhi syarat penilaian UAS mata kuliah Pemrograman Web Dasar. Aplikasi ini mengimplementasikan konsep CRUD lengkap menggunakan PHP Native dan basis data MySQL, serta dilengkapi dengan manajemen file CSS eksternal.

---

## 1. Identitas Mahasiswa
* **Nama:** Sulis Inayah Masruro
* **NIM:** [Masukkan NIM Kamu di Sini, Contoh: 2025090xxx]
* **Mata Kuliah:** Pemrograman Web

---

## 2. Judul Aplikasi
**Sistem Informasi Inventaris Barang Toko (CRUD + Perhitungan Aset Otomatis)**

---

## 3. Deskripsi Singkat
Aplikasi ini adalah sistem manajemen inventaris berbasis web yang dirancang untuk mendata barang di toko atau gudang. Sistem ini memiliki 4 halaman utama (Home, Tambah Barang, Daftar Barang, dan Edit Barang) yang mendukung fitur:
* **Create:** Menambahkan data barang baru (Kode, Nama, Kategori, Stok, Harga).
* **Read:** Menampilkan semua daftar inventaris ke dalam tabel rapi.
* **Update:** Mengubah data spesifik barang yang sudah terdaftar.
* **Delete:** Menghapus data barang dengan konfirmasi aman.
* **Fungsi Kustom PHP:** Menggunakan fungsi `formatRupiah()` untuk standarisasi mata uang dan fungsi `hitungAset()` untuk mengalkulasi total nilai aset gudang secara otomatis (*real-time*).

---

## 4. Screenshot Aplikasi
Berikut adalah tampilan halaman antarmuka aplikasi:

### Halaman Utama (Home)
![Halaman Home](screenshot-home.png)
*(Catatan: Ganti dengan file gambar screenshot halaman index.php kamu)*

### Halaman Daftar Barang
![Halaman Daftar Barang](screenshot-daftar.png)
*(Catatan: Ganti dengan file gambar screenshot halaman daftar.php kamu)*

---

## 5. Struktur Database
Aplikasi ini menggunakan database bernama `inventaris_barang` dengan struktur tabel `barang` sebagai berikut:

```sql
CREATE TABLE barang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    kode_barang VARCHAR(20) NOT NULL,
    nama_barang VARCHAR(100) NOT NULL,
    kategori VARCHAR(50) NOT NULL,
    stok INT NOT NULL,
    harga INT NOT NULL
);